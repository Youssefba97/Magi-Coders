void ajouterutilisateur(char nom[30], char mdp[30]);
int verifierutilisateur(char nom[],char mdp[]);
