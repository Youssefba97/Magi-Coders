#include<gtk/gtk.h>
#ifndef TREE_H_
#define TREE_H_

void SpringTreeView(GtkWidget* TreeView,char*filename);
void SummerTreeView(GtkWidget* TreeView,char*filename);
void AutumnTreeView(GtkWidget* TreeView,char*filename);
void WinterTreeView(GtkWidget* TreeView,char*filename);

#endif
