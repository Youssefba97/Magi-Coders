void AfficherAnimal(GtkWidget* treeview1,char*l);
void AfficherRechercheAnimal(GtkWidget* treeview1,char*l);

